import {test, expect} from '@playwright/test';

test.describe('login test', ()=>{
   test('Vaild login', async ({page}, testinfo)=> {

    await page.goto('https://opensource-demo.orangehrmlive.com/');
    await page.locator("//input[@id='username']").fill("Admin");
    await page.locator("//input[@id='password']").fill("admin123");
    await page.getByRole('button',{name:'Login'} ).click();
    await expect(page.getByAltText("profile picture")).toBeVisible();
});



test('Invaild login', async ({page})=> {

    await page.goto('https://opensource-demo.orangehrmlive.com/');
    await page.locator("//input[@id='username']").fill("Admin");
    await page.locator("//input[@id='password']").fill("admin12");
    await page.getByRole('button',{name:'Login'} ).click();
    await expect(page.locator("//p[@class='oxd-text oxd-text--p oxd-alert-content-text']'] b")).toHaveText("Invalid credentials")
});
});