
import { test, expect } from '@playwright/test';

test.describe('login test', () => {

    test('Valid login', async ({ page }) => {

        await page.goto('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');

        await page.locator("//input[@name='username']").fill("Admin");
        await page.locator("//input[@name='password']").fill("admin123");

        await page.getByRole('button', { name: 'Login' }).click();

        await expect(page.getByAltText("profile picture")).toBeVisible();
    });

    test('Invalid login', async ({ page }) => {

        await page.goto('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');

        await page.locator("//input[@name='username']").fill("Admin");
        await page.locator("//input[@name='password']").fill("admin12");

        await page.getByRole('button', { name: 'Login' }).click();

        await expect(page.locator('.oxd-alert-content-text')).toHaveText("Invalid credentials");

    });

});
